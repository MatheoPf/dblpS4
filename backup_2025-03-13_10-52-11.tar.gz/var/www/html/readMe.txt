Tuto comment se connecté au projet :

Aller sur vsc 3ème onglet puis 1er bouton
3petit point puis clone coller https://github.com/MatheoPf/dblpS4.git
puis pacer dans votre dossier de travail
dans le terminal :

git config --global user.name "<nomGithub>"
git config --global user.email "<emailGithub>"
Pour changer de branche :

git pull
puis en bas a gauche on peut changer de branche
